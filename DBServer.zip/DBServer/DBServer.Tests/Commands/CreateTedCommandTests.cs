﻿using DBServer.Domain.Commands.ContaCorrenteCommands.Inputs;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace DBServer.Tests.Commands
{
    [TestClass]
    public class CreateTedCommandTests
    {
        [TestMethod]
        public void ShouldValidateWhenCommandIsValid()
        {
            var command = new CreateTedCommand
            {
                CodigoBancoFavorecido = "237",
                CodigoAgenciaFavorecido = "3345",
                DocumentoFavorecido = "407.989.650-61",
                TipoDocumento = Domain.Enums.ETipoDocumento.CPF,
                Email = "teste@dbServer.com.br",                
                CodigoContaFavorecido = "3435345",
                DataPagamento = DateTime.Now,
                NomeFavorecido = "Jose",
                SobrenomeFavorecido = "Junior",
                Valor = 1000.00M
                
            };

            Assert.AreEqual(true, command.EstaValido());
        }
    }
}
