﻿using DBServer.Domain.Services;

namespace DBServer.Tests.Mocks
{
    public class EmailServiceMock : IEmailService
    {
        public void Send(string to, string from, string subject, string body)
        {
           //Implrementar
        }
    }
}
