﻿using DBServer.Domain.Entities;
using DBServer.Domain.Repositories;
using DBServer.Domain.ValueObjects;
using System;

namespace DBServer.Tests.Mocks
{
    public class TransferenciaRepositoryMock : ITransferenciaRepository
    {
        public void AtualizaStatusPagamento(Pagamento pagamento)
        {
            //Implementar
        }

        public void LancarMovimento(MovimentoContaCorrente movimento)
        {
            //Implementar
        }

        public void RealizarTed(Ted Ted)
        {
            //Implementar
        }

        public void SalvarPagamento(Pagamento pagamento)
        {
            //Implementar
        }
    }
}
