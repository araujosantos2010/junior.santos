﻿using DBServer.Domain.Entities;
using DBServer.Domain.ValueObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DBServer.Tests.Entities
{
    //Coloquei somente alguns cenários

    [TestClass]
    public class ClienteTests
    {
        private Nome _nome;
        private Documento _documento;
        private Email _email;
        private Cliente _cliente;

        public ClienteTests()
        {
           _nome = new Nome("josé", "Junior");
           _documento = new Documento("885.163.380-02", Domain.Enums.ETipoDocumento.CPF);
           _email = new Email("teste@dbserver.com.br");

            _cliente = new Cliente(_nome, _documento, _email);
        }

        [TestMethod]
        public void ClienteDeveSerValido()
        {  
            Assert.AreEqual(true, _cliente.Valid);
        }

        [TestMethod]
        public void DeveAdicionarCOntaCorrenteAoCliente()
        {
            _cliente.AdicionarContaCorrente("0345", "0011234");
            _cliente.AdicionarContaCorrente("0345", "0011874");

            Assert.AreEqual(true, _cliente.Valid);
        }

    }
}
