﻿using DBServer.Domain.ValueObjects;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DBServer.Tests.Entities
{
    //Coloquei somente alguns cenários
   [TestClass]
   public  class DocumentoTests
   {
        [TestMethod]
        public void  DocumentoCPFDeveSerValido()
        {
            var documento = new Documento("885.163.380-02", Domain.Enums.ETipoDocumento.CPF);
            Assert.AreEqual(true, documento.Valid);
        }

        [TestMethod]
        public void DocumentoCNPJDeveSerValido()
        {
            var documento = new Documento("95.308.268/0001-00", Domain.Enums.ETipoDocumento.CNPJ);
            Assert.AreEqual(true, documento.Valid);
        }

    }
}
