﻿using DBServer.Domain.Commands.ContaCorrenteCommands.Inputs;
using DBServer.Domain.Entities;
using DBServer.Domain.Enums;
using DBServer.Domain.Handlers;
using DBServer.Domain.ValueObjects;
using DBServer.Tests.Mocks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DBServer.Tests.Handlers
{
    [TestClass]
    public class TedHandlerTests
    {
        [TestMethod]
        public void ShouldRegisterCustomerWhenCommandIsValid()
        {

            var command = new CreateTedCommand
            {
                CodigoBancoFavorecido = "237",
                CodigoAgenciaFavorecido = "3345",
                DocumentoFavorecido = "407.989.650-61",
                TipoDocumento = Domain.Enums.ETipoDocumento.CPF,
                Email = "teste@dbServer.com.br",
                CodigoContaFavorecido = "3435345",
                DataPagamento = DateTime.Now,
                NomeFavorecido = "Jose",
                SobrenomeFavorecido = "Junior",
                Valor = 1000.00M

            };
            
            var handler = new TedHandler(new TransferenciaRepositoryMock(), new EmailServiceMock());
            var result = handler.Handle(command);

            Assert.AreNotEqual(null, result);
            Assert.AreEqual(true, handler.Valid);
        }
    }
}
