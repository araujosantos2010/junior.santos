﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBServer.Domain.Enums
{
    public enum ETipoDocumento
    {
        CPF = 1,
        CNPJ = 2
    }
}
