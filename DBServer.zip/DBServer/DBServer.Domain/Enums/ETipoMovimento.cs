﻿namespace DBServer.Domain.Enums
{
    public enum ETipoMovimento
    {
        Debito = 1,
        Credito = 2
    }
}
