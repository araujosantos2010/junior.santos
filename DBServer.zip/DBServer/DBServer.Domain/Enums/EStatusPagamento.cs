﻿namespace DBServer.Domain.Enums
{
    public enum EStatusPagamento
    {
        EmProcessamento = 1,
        EmEfetivacao = 2,
        Cancelado = 3,
        Aprovado = 4,
        Recusado = 5,
        Efetivado = 6
    }
}
