﻿namespace DBServer.Domain.Enums
{
    public enum ETipoTrasnferencia
    {
        TedC = 1,
        TedD = 2
    }
}
