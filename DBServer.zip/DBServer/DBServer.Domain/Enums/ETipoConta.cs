﻿namespace DBServer.Domain.Enums
{
    public enum ETipoConta
    {
        ContaCorrente = 1,
        ContaPoupanca = 2
    }
}
