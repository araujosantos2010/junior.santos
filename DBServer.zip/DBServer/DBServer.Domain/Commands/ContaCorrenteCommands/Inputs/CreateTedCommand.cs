﻿using DBServer.Domain.Enums;
using DBServer.Shared.Commands;
using FluentValidator;
using FluentValidator.Validation;
using System;

namespace DBServer.Domain.Commands.ContaCorrenteCommands.Inputs
{
    public class CreateTedCommand : Notifiable, ICommand
    {
        public decimal Valor { get; set; }
        public string NomeFavorecido { get; set; }
        public string SobrenomeFavorecido { get; set; }
        public string CodigoContaFavorecido { get; set; }
        public string CodigoAgenciaFavorecido { get; set; }
        public string CodigoBancoFavorecido { get; set; }
        public string NomeBancoFavorecido { get; set; }
        public string NomeAgenciaFavorecido { get; set; }
        public string DocumentoFavorecido { get; set; }
        public DateTime DataPagamento { get; set; }
        public ETipoDocumento TipoDocumento { get; set; }
        public ETipoTrasnferencia TipoTransferencia { get; set; }
        public string Email { get; set; }
        public string EmailFavorecido { get; private set; }

        public bool EstaValido()
        {
            //Somente algumas validacoes

            AddNotifications(new ValidationContract()
               .HasMinLen(NomeFavorecido, 3, "NomeCliente", "O nome deve conter pelo menos 3 caracteres")
               .HasMaxLen(NomeFavorecido, 40, "NomeCliente", "O nome deve conter no máximo 40 caracteres")
               .HasMinLen(SobrenomeFavorecido, 3, "SobrenomeFavorecido", "O sobrenome deve conter pelo menos 3 caracteres")
               .HasMaxLen(SobrenomeFavorecido, 40, "SobrenomeFavorecido", "O sobrenome deve conter no máximo 40 caracteres")
               .IsEmail(Email, "Email", "O E-mail é inválido")
               .HasMaxLen(CodigoAgenciaFavorecido, 5, "Agencia", "Agencia inválida")
               .HasMaxLen(CodigoContaFavorecido, 8, "Conta", "Conta inválida")
               .HasMaxLen(CodigoBancoFavorecido, 5, "Banco", "Banco inválido")
           );
            if (TipoDocumento == ETipoDocumento.CPF)
                AddNotifications(new ValidationContract()
                     .HasLen(DocumentoFavorecido, 11, "Document", "CPF inválido"));
            else 
                AddNotifications(new ValidationContract()
                    .HasLen(DocumentoFavorecido, 14, "Document", "CNPJ inválido"));

            return Valid;
        }

        
    }
}
