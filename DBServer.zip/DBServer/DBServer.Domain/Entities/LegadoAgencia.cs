﻿using DBServer.Shared;

namespace DBServer.Domain.Entities
{
    public sealed class LegadoAgencia : EntidadeBase
    {
        public LegadoAgencia(LegadoBanco banco, string codigoAgencia, string nome)
        {
            Banco = banco;
            CodigoAgencia = codigoAgencia;
            Nome = nome;
        }

        public LegadoBanco Banco { get; private set; }
        public string CodigoAgencia { get; private set; }
        public string Nome { get; private set; }

        public override string ToString()
        {
            return $"{Banco.Nome} / Ag: {CodigoAgencia} - {Nome}";
        }
    }
}
