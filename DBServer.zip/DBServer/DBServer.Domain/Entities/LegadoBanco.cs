﻿using DBServer.Shared;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBServer.Domain.Entities
{
    public sealed class LegadoBanco : EntidadeBase
    {
        public LegadoBanco(string nome, string codigoBanco)
        {
            Nome = nome;
            CodigoBanco = codigoBanco;
        }

        public string Nome { get; private set; }
        public string CodigoBanco { get; private set; }       

        public override string ToString()
        {
            return $"{CodigoBanco} - {Nome}";
        }
    }
}
