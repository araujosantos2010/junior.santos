﻿using DBServer.Shared;
using FluentValidator;

namespace DBServer.Domain.Entities
{
    public class ContaCorrente : EntidadeBase
    {
        public ContaCorrente(string codigoConta, string codigoAgencia)
        {
            CodigoConta = codigoConta;
            CodigoAgencia = codigoAgencia;
        }

        public string CodigoConta { get; private set; }
        public string CodigoAgencia { get; private set; }

        public override string ToString()
        {
            return $"Ag: {CodigoAgencia} Conta: {CodigoAgencia}";
        }
    }
}
