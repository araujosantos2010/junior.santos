﻿using DBServer.Domain.Enums;
using DBServer.Shared;
using System;

namespace DBServer.Domain.Entities
{
    public class Pagamento : EntidadeBase
    {
        public Pagamento(ContaCorrente contaCorrente, Cliente cliente, decimal valorPagamento, DateTime dataPagamento, CnabPagamento cnabPagamento)
        {
            ContaCorrente = contaCorrente;
            Cliente = cliente;
            ValorPagamento = valorPagamento;
            DataCriacao = DateTime.Now;
            DataPagamento = dataPagamento;
            StatusPagamento = EStatusPagamento.EmProcessamento;
            CnabPagamento = cnabPagamento;
        }

        public ContaCorrente ContaCorrente { get; private set; }
        public Cliente Cliente { get; private set; }
        public decimal ValorPagamento { get; private set; }
        public DateTime DataCriacao { get; private set; }
        public DateTime DataPagamento { get; private set; }
        public EStatusPagamento StatusPagamento{ get; private set; }
        public CnabPagamento CnabPagamento { get; set; }

        public void PagamentoEmProcessamento()
        {
            StatusPagamento = EStatusPagamento.EmEfetivacao;
        }

        public void PagamentoEfetivado()
        {
            StatusPagamento = EStatusPagamento.Efetivado;
        }

        public void PagamentoCancelado()
        {
            StatusPagamento = EStatusPagamento.EmEfetivacao;
        }

    }
}
