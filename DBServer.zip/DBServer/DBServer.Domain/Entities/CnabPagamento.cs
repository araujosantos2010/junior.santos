﻿using DBServer.Shared;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBServer.Domain.Entities
{
    public sealed class CnabPagamento : EntidadeBase
    {
        public CnabPagamento(string codigoBancoCompensacao, string codigoBancoFavorecido, string codigoContaCorrente, string nomeFavorecido, DateTime dataPagamento, decimal valorPagamento)
        {
            CodigoBancoCompensacao = codigoBancoCompensacao;
            CodigoBancoFavorecido = codigoBancoFavorecido;
            CodigoContaCorrente = codigoContaCorrente;
            NomeFavorecido = nomeFavorecido;
            DataPagamento = dataPagamento;
            ValorPagamento = valorPagamento;
        }

        public string CodigoBancoCompensacao { get; private set; }
        public string CodigoBancoFavorecido { get; private set; }
        public string CodigoContaCorrente { get; private set; }
        public string NomeFavorecido { get; private set; }
        public DateTime DataPagamento { get; private set; }
        public decimal ValorPagamento { get; private set; }
    }
}
