﻿using DBServer.Domain.Enums;
using DBServer.Shared;

namespace DBServer.Domain.Entities
{
    public class MovimentoContaCorrente : EntidadeBase      
    {
        public MovimentoContaCorrente(ContaCorrente contaCorrente, Cliente cliente, ETipoMovimento tipoMovimento, Pagamento pagamento)
        {
            ContaCorrente = contaCorrente;
            Cliente = cliente;
            TipoMovimento = tipoMovimento;
            Pagamento = pagamento;
        }

        public ContaCorrente ContaCorrente { get; private set; }
        public Cliente Cliente { get; private set; }
        public ETipoMovimento TipoMovimento { get; private set; }
        public Pagamento Pagamento { get; private set; }
    }
}
