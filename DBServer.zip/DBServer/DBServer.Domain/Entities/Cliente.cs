﻿using DBServer.Domain.ValueObjects;
using DBServer.Shared;
using System.Collections.Generic;
using System.Linq;

namespace DBServer.Domain.Entities
{
    public class Cliente : EntidadeBase
    {
        private readonly IList<ContaCorrente> _contasCorrente;

        public Cliente(Nome nome, Documento documento, Email email)
        {  
            Nome = nome;
            Documento = documento;
            Email = email;
            _contasCorrente = new List<ContaCorrente>();
        }

        public Nome Nome { get; private set; }
        public Documento Documento { get; private set; }
        public Email Email { get; private set; }
        public IReadOnlyCollection<ContaCorrente> ContasCorrente => _contasCorrente.ToArray();

        public void AdicionarContaCorrente(string codigoAgencia, string codigoConta)
        {
            var conta = new ContaCorrente(codigoAgencia, codigoConta);
            _contasCorrente.Add(conta);
        }
    }
}
