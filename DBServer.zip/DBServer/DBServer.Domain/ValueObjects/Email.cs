﻿using FluentValidator;

namespace DBServer.Domain.ValueObjects
{
    public class Email : Notifiable
    {
        public Email(string endereco)
        {
            Endereco = endereco;
        }

        public string Endereco { get;private set; }        
    }
}
