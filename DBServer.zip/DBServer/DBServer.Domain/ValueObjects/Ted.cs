﻿using DBServer.Domain.Entities;
using DBServer.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBServer.Domain.ValueObjects
{
    public class Ted : Transferencia
    {
        public Ted(Documento documento, Favorecido favorecido, Cliente cliente, ContaCorrente contaCorrente, ETipoTrasnferencia tipoTransferencia, decimal valor, DateTime data)
           : base(cliente, contaCorrente, tipoTransferencia, valor, data)
        {
            Documento = documento;
            Favorecido = favorecido;
        }

        public Documento Documento { get; private set; }
        public Favorecido Favorecido { get; private set; }
    }
}
