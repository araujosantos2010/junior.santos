﻿using DBServer.Domain.Entities;
using DBServer.Domain.Enums;
using System;

namespace DBServer.Domain.ValueObjects
{
    public sealed class TransferenciaInterna : Transferencia
    {
        public TransferenciaInterna(Favorecido favorecido, Cliente cliente, ContaCorrente contaCorrente, ETipoTrasnferencia tipoTransferencia, decimal valor, DateTime data)
            :base(cliente,contaCorrente,tipoTransferencia,valor,data)
        {
            Favorecido = favorecido;
        }

        public Favorecido Favorecido { get; private set; }
    }
}
