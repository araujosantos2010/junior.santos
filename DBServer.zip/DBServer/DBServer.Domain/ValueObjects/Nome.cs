﻿using FluentValidator;
using FluentValidator.Validation;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBServer.Domain.ValueObjects
{
    public class Nome : Notifiable
    {
        public Nome(string nomeCliente, string sobrenomeCliente)
        {
            NomeCliente = nomeCliente;
            SobrenomeCliente = sobrenomeCliente;

            AddNotifications(new ValidationContract()
               .Requires()
               .HasMinLen(NomeCliente, 3, "NomeCliente", "O nome deve conter pelo menos 3 caracteres")
               .HasMaxLen(NomeCliente, 40, "NomeCliente", "O nome deve conter no máximo 40 caracteres")
               .HasMinLen(SobrenomeCliente, 3, "SobrenomeCliente", "O sobrenome deve conter pelo menos 3 caracteres")
               .HasMaxLen(SobrenomeCliente, 40, "SobrenomeCliente", "O sobrenome deve conter no máximo 40 caracteres")
           );
        }

        public string NomeCliente { get; private set; }
        public string SobrenomeCliente { get; private set; }

        public override string ToString()
        {
            return $"{NomeCliente} {SobrenomeCliente}";
        }
    }
}
