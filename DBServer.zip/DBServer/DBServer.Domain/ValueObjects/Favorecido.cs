﻿using DBServer.Domain.Entities;

namespace DBServer.Domain.ValueObjects
{
    public sealed class Favorecido
    {

        public Favorecido(Nome nome, Documento documento, LegadoBanco legadoBanco, LegadoAgencia legadoAgencia, Email email)
        {
            Nome = nome;
            Documento = documento;
            LegadoBanco = legadoBanco;
            LegadoAgencia = legadoAgencia;
            Email = email;
        }

        public Nome Nome { get; private set; }
        public Documento Documento { get; set; }
        public LegadoBanco LegadoBanco { get; private set; }
        public LegadoAgencia LegadoAgencia { get; private set; }
        public Email Email { get; set; }

    }
}
