﻿using DBServer.Domain.Entities;
using DBServer.Domain.Enums;
using System;

namespace DBServer.Domain.ValueObjects
{
    public abstract class Transferencia
    {
        protected Transferencia(Cliente cliente, ContaCorrente contaCorrente, ETipoTrasnferencia tipoTransferencia, decimal valor, DateTime data)
        {
            Cliente = cliente;
            ContaCorrente = contaCorrente;
            TipoTransferencia = tipoTransferencia;
            Valor = valor;
            Data = data;
        }

        public Cliente Cliente { get; private set; }
        public ContaCorrente ContaCorrente { get; private set; }
        public ETipoTrasnferencia TipoTransferencia { get; private set; }
        public decimal Valor { get; private set; }
        public DateTime Data { get; private set; }
    }
}
