﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBServer.Domain.ValueObjects
{
    public class Conta
    {
        public string Agencia { get; private set; }
        public string NumeroConta { get; set; }
        public string Ban { get; set; }
    }
}
