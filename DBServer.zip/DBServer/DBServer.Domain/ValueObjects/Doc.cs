﻿using DBServer.Domain.Entities;
using DBServer.Domain.Enums;
using System;

namespace DBServer.Domain.ValueObjects
{
    public sealed class Doc : Transferencia
    {
        public Doc(Documento documento, Favorecido favorecido, Cliente cliente, ContaCorrente contaCorrente, ETipoTrasnferencia tipoTransferencia, decimal valor, DateTime data)
            : base(cliente, contaCorrente, tipoTransferencia, valor, data)
        {
            Documento = documento;
            Favorecido = favorecido;
        }

        public Documento Documento { get; private set; }
        public Favorecido Favorecido { get; private set; }
    }
}
