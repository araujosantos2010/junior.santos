﻿using DBServer.Domain.Entities;
using DBServer.Domain.ValueObjects;

namespace DBServer.Domain.Repositories
{
    public interface ITransferenciaRepository
    {
        void RealizarTed(Ted Ted);
        void SalvarPagamento(Pagamento pagamento);
        void AtualizaStatusPagamento(Pagamento pagamento);
        void LancarMovimento(MovimentoContaCorrente movimento);
    }
}
