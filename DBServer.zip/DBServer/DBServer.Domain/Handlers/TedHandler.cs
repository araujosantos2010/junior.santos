﻿using DBServer.Domain.Commands.ContaCorrenteCommands.Inputs;
using DBServer.Domain.Commands.ContaCorrenteCommands.Outputs;
using DBServer.Domain.Entities;
using DBServer.Domain.Enums;
using DBServer.Domain.Repositories;
using DBServer.Domain.Services;
using DBServer.Domain.ValueObjects;
using DBServer.Shared.Commands;
using FluentValidator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DBServer.Domain.Handlers
{
    public class TedHandler : Notifiable, ICommandHandler<CreateTedCommand>
    {
        private readonly ITransferenciaRepository _repository;
        private readonly IEmailService _emailService;

        public TedHandler(ITransferenciaRepository repository, IEmailService emailService)
        {
            _repository = repository;
            _emailService = emailService;
        }

        public ICommandResult Handle(CreateTedCommand command)
        {
            command.EstaValido();

            if (command.Invalid)
            {
                AddNotifications(command);
                return new CommandResult(false, "Não foi possível realizar sua ted", command);
            }


            //Criei o cliente aqui somente para conseguir agilizar o teste 
            //Para não ficar muito extenso
            //Estou considerando que o cliente possui saldo em conta
            //Não estou fazendo essas validações

            var nome = new Nome("josé", "Junior");
            var documento = new Documento("885.163.380-02", ETipoDocumento.CPF);
            var email = new Email("teste@dbserver.com.br");
            var cliente = new Cliente(nome, documento, email);
            cliente.AdicionarContaCorrente("0345", "0011234");
            var contaCorrente = cliente.ContasCorrente.First();
            //

            var nomeFavorecido = new Nome(command.NomeFavorecido, command.SobrenomeFavorecido);

            var documentoFavorecido = new Documento(command.DocumentoFavorecido, command.TipoDocumento);
            var legadoBanco = new LegadoBanco(command.NomeBancoFavorecido, command.CodigoBancoFavorecido);
            var legadoAgencia = new LegadoAgencia(legadoBanco, command.CodigoAgenciaFavorecido, command.NomeAgenciaFavorecido);
            var emailFavorecido = new Email(command.EmailFavorecido);

            var favorecido = new Favorecido(nomeFavorecido, documentoFavorecido, legadoBanco, legadoAgencia, emailFavorecido);

            AddNotifications(nome, documento, email, cliente);

            if (Invalid)
                return new CommandResult(
                    false,
                    "Por favor, corrija os campos abaixo",
                    Notifications);


            var cnab = new CnabPagamento("456", command.CodigoBancoFavorecido, command.CodigoContaFavorecido, favorecido.ToString(), command.DataPagamento, command.Valor);

            //gera o pagamento
            var pagamento = new Pagamento(contaCorrente, cliente, command.Valor, command.DataPagamento, cnab);

            pagamento.PagamentoEmProcessamento();

            _repository.SalvarPagamento(pagamento);

            //Aqui teria Uma outra entidade para ir registrando eventos do pagamento (status)
            //Porém vou simular aqui

            //Realiza a Ted
            var ted = new Ted(documento, favorecido, cliente, contaCorrente, command.TipoTransferencia, command.Valor, command.DataPagamento);

            //Realizar TED
            _repository.RealizarTed(ted);

            //Simulo a efetivação do pagamento (status efetivado)
            pagamento.PagamentoEfetivado();
            _repository.AtualizaStatusPagamento(pagamento);

            //Lancar Movimento na conta
            var movimento = new MovimentoContaCorrente(contaCorrente, cliente, ETipoMovimento.Debito, pagamento);
            _repository.LancarMovimento(movimento);


            //Enviar comprovante por email
            _emailService.Send(favorecido.Email.Endereco, cliente.Email.Endereco, "Comprovante",
                $"Origem {contaCorrente.ToString()} Destino ...");

            // Retornar o resultado para tela
            return new CommandResult(true, "Ted Realizada", new
            {
                ted.Favorecido,
                ContaCorrente = contaCorrente.ToString()
            });
        }
    }
}
