﻿using DBServer.Domain.Commands.ContaCorrenteCommands.Inputs;
using DBServer.Domain.Commands.ContaCorrenteCommands.Outputs;
using DBServer.Domain.Handlers;
using DBServer.Domain.Repositories;
using DBServer.Shared.Commands;
using Microsoft.AspNetCore.Mvc;

namespace DBServer.Api.Controllers
{
    public class TransferenciaController
    {
        private readonly ITransferenciaRepository _repository;
        private readonly TedHandler _handler;

        public TransferenciaController(ITransferenciaRepository repository, TedHandler handler)
        {
            _repository = repository;
            _handler = handler;
        }

        [HttpPost]
        [Route("Ted")]
        public ICommandResult Post([FromBody]CreateTedCommand command)
        {
            var result = (CommandResult)_handler.Handle(command);
            return result;
        }
    }
}
