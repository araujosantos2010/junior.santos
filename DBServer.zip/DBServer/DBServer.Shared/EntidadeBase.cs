﻿using FluentValidator;
using System;

namespace DBServer.Shared
{
    public abstract class EntidadeBase : Notifiable
    {
        public EntidadeBase()
        {
            Id = Guid.NewGuid();
        }
        public Guid Id { get; private set; }
    }
}
