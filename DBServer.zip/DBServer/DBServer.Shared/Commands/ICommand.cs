﻿namespace DBServer.Shared.Commands
{
    public interface ICommand
    {
        bool EstaValido();
    }
}
