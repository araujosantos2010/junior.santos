﻿namespace DBServer.Shared
{
    public static class Settings
    {
        public static string ConnectionString = @"data source=JUNIOR;initial catalog=baltastore;persist security info=True;Integrated Security=SSPI;";
    }
}
