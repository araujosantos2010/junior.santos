﻿using DBServer.Domain.Services;
using System;

namespace DBServer.Infra.Services
{
    public class EmailService : IEmailService
    {
        public void Send(string to, string from, string subject, string body)
        {
            //Implementar
        }
    }
}
