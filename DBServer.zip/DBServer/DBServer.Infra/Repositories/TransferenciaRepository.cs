﻿using Dapper;
using DBServer.Domain.Entities;
using DBServer.Domain.Repositories;
using DBServer.Domain.ValueObjects;
using DBServer.Infra.DataContexts;
using System;
using System.Data;

namespace DBServer.Infra.Repositories
{
    public class TransferenciaRepository : ITransferenciaRepository
    {
        private readonly DBServerContext _context;

        public TransferenciaRepository(DBServerContext context)
        {
            _context = context;
        }

        public void AtualizaStatusPagamento(Pagamento pagamento)
        {
           //Implementar
        }

        public void LancarMovimento(MovimentoContaCorrente movimento)
        {
            //IMplementar
        }

        public void RealizarTed(Ted Ted)
        {
           //IMplementar
        }

        public void SalvarPagamento(Pagamento pagamento)
        {
           _context.Connection.Execute("spCriarPagamento",
           new
           {
              //Paramwtros do Pagamento
           }, commandType: CommandType.StoredProcedure);
        }
    }
}
